let names = "shek showkath";
let age = "1";
let city = "thandarampet";
let role = "engineer";
let output = "";

output = "<table border='1'><tr><th>NAME</th><td>" + names + "</td></tr><tr><th>AGE</th><td>" + age + "</td></tr><tr><th>CITY</th><td>" + city + "</td></tr><tr><th>ROLE</th><td>" + role + "</td></tr></table>";

// ES5
output += "<hr><table border='1'>" +
    "<tr><th>NAME</th><td>" + names + "</td></tr>" +
    "<tr><th>AGE</th><td>" + age + "</td></tr>" +
    "<tr><th>CITY</th><td>" + city + "</td></tr>" +
    "<tr><th>ROLE</th><td>" + role + "</td></tr>" +
    "</table>";

// ES6
output += `<hr><table border='1'>
<tr><th>NAME</th><td>${names}</td></tr>
<tr><th>AGE</th><td>${age >= 18 ? "GOOD" : "BAD"}</td></tr>
<tr><th>CITY</th><td>${city}</td></tr>
<tr><th>ROLE</th><td>${role}</td></tr>
</table>`;
// let shek="";
shek="<p>I'M GROOT</p>"
document.body.innerHTML = output;
// document.body.innerHTML=shek;

const number=[1,2,3,4,5,6,7,8,9,0];

number.forEach((value)=>{
    console.log(value);
});

number.forEach((value,index)=>{
    console.log(index+" "+value);
});
const numbers=[1,2,3,4,5,6,7,8,9,0];

let sqrt=numbers.map((value)=>{
    return Math.sqrt(value);
});
console.table(sqrt);