let fname=document.getElementById("fname");
let lname=document.getElementById("lname");
let faname=document.getElementById("faname");
let gender=document.getElementById("gender");
let dob=document.getElementById("dob");
let email=document.getElementById("email");
let department=document.getElementById("department");
let contact=document.getElementById("contact");
let va = /^([a-zA-Z\s]+)$/;
function validateInput() {
    // console.log("validate input");

    // check fname is empty
    if (fname.value.trim()==="") {
        onError(fname,"FIRST NAME CANNOT BE EMPTY");
    } else  {
        onSuccess(fname);
    } 

    // check lname is empty
    if (lname.value.trim()==="") {
        onErrorl(lname,"LAST NAME CANNOT BE EMPTY");
    } else  {
        onSuccessl(lname);
    } 
    // check faname is empty
    if (faname.value.trim()==="") {
        onErrorfa(faname,"FATHER'S NAME CANNOT BE EMPTY");
    } else  {
        onSuccessfa(faname);
    }

    if (gender.value.trim()==="") {
        onErrorgen(gender,"PLEASE SELECT GENDER");
    } else  {
        onSuccessgen(gender);
    }
    // check dob
    if (dob.value.trim()==="") {
        onErrordob(dob,"PLEASE SELECT DATE OF BIRTH");
    } else  {
        onSuccessdob(dob);
    }

    // check department
    if (department.value.trim()==="") {
        onErrordep(department,"PLEASE SELECT DEPARTMENT");
    } else  {
        onSuccessdep(department);
    }

    // check contact
    if (contact.value.trim()==="") {
        onErrorcon(contact,"PLEASE SELECT CONTACT");
    } else  {
        onSuccesscon(contact);
    }

    // check email
    if (email.value.trim() ==='') {
        onErrorem(email, 'EMAIL CANNOT BE BLANK');
    } else if(!isEmail(email)){
        onErrorem(email, 'EMAIL CANNOT BE VALID');
    } else{
        onSuccessem(email);
    }
}

document.querySelector("button")
.addEventListener("click", (event)=>{
    event.preventDefault();
    validateInput();
});

function onSuccess(input) {
    let parent=fname.parentElement;
    
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="hidden";
    messageEle.innerText="";
    parent.classList.remove("error");
    parent.classList.add("sucess");
}

function onError(input,message) {
    let parent=fname.parentElement;
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="visible";
    messageEle.innerText=message;
    parent.classList.remove("sucess");
    parent.classList.add("error");
}

function onSuccessl(input) {
    let parent=lname.parentElement;
    
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="hidden";
    messageEle.innerText="";
    parent.classList.remove("error");
    parent.classList.add("sucess");
}
function onErrorl(input,message) {
    let parent=lname.parentElement;
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="visible";
    messageEle.innerText=message;
    parent.classList.remove("sucess");
    parent.classList.add("error");
}

function onSuccessfa(input) {
    let parent=faname.parentElement;
    
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="hidden";
    messageEle.innerText="";
    parent.classList.remove("error");
    parent.classList.add("sucess");
}
function onErrorfa(input,message) {
    let parent=faname.parentElement;
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="visible";
    messageEle.innerText=message;
    parent.classList.remove("sucess");
    parent.classList.add("error");
}

function onSuccessgen(input) {
    let parent=gender.parentElement;
    
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="hidden";
    messageEle.innerText="";
    parent.classList.remove("error");
    parent.classList.add("sucess");
}
function onErrorgen(input,message) {
    let parent=gender.parentElement;
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="visible";
    messageEle.innerText=message;
    parent.classList.remove("sucess");
    parent.classList.add("error");
}


function onSuccessdob(input) {
    let parent=dob.parentElement;
    
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="hidden";
    messageEle.innerText="";
    parent.classList.remove("error");
    parent.classList.add("sucess");
}

function onErrordob(input,message) {
    let parent=dob.parentElement;
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="visible";
    messageEle.innerText=message;
    parent.classList.remove("sucess");
    parent.classList.add("error");
}

function onSuccessdep(select) {
    let parent=department.parentElement;
    
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="hidden";
    messageEle.innerText="";
    parent.classList.remove("error");
    parent.classList.add("sucess");
}

function onErrordep(select,message) {
    let parent=department.parentElement;
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="visible";
    messageEle.innerText=message;
    parent.classList.remove("sucess");
    parent.classList.add("error");
}

function onSuccesscon(input) {
    let parent=contact.parentElement;
    
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="hidden";
    messageEle.innerText="";
    parent.classList.remove("error");
    parent.classList.add("sucess");
}

function onErrorcon(input,message) {
    let parent=contact.parentElement;
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="visible";
    messageEle.innerText=message;
    parent.classList.remove("sucess");
    parent.classList.add("error");
}

function onSuccessem(input) {
    let parent=email.parentElement;
    
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="hidden";
    messageEle.innerText="";
    parent.classList.remove("error");
    parent.classList.add("sucess");
}
function onErrorem(input,message) {
    let parent=email.parentElement;
    let messageEle=parent.querySelector("small");
    messageEle.style.visibility="visible";
    messageEle.innerText=message;
    parent.classList.remove("sucess");
    parent.classList.add("error");
}


function isEmail(email) {
    return /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);
}