output=`<table border='1'>
<tr>
    <td class='personalid'>i</td>
    <td>SHEK</td>
</tr>
<tr>
    <td class='personalid'>i</td>
    <td>KULANDAI</td>
</tr>
<tr>
    <td class='personalid'>i</td>
    <td>TAMIL</td>
</tr>
<tr>
    <td class='personalid'>i</td>
    <td>SRI</td>
</tr>
<tr>
    <td class='personalid'>i</td>
    <td>NAVEEN</td>
</tr>
<tr>
    <td class='personalid'>i</td>
    <td>PANDI</td>
</tr>
</table>`;
document.body.innerHTML=output;
var list=document.getElementsByClassName("personid");
for(var i=1,td; i<=list.length; i++){
    list[i].innerHTML=i;
}
