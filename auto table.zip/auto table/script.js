outputTable=`<table border='1'>
<tr><td>SHEK</td><td>KULANDAI</td></tr>
<tr><td>KULANDAI</td><td>SHEK</td></tr>
<tr><td>TAMIL</td><td>SHEK</td></tr>
<tr><td>SRI</td><td>SHEK</td></tr>
<tr><td>PANDI</td><td>SHEK</td></tr>
<tr><td>nishanth</td><td>SHEK</td></tr>
<tr><td>naveen</td><td>SHEK</td></tr>
</table>`;



document.body.innerHTML=outputTable;

var tables=document.getElementsByTagName('table');
var table=tables[tables.length-1];
var rows=table.rows;

for(var i=0,td; i<rows.length; i++){
    td=document.createElement('td');
    td.appendChild(document.createTextNode(i+1));
    rows[i].insertBefore(td, rows[i].firstChild);
}