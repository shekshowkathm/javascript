var selectorRow = null;

// show Alerts
function showAlert(message, className) {
    const div = document.createElement("div");
    div.className = `alert alert-${className}`;

    div.appendChild(document.createTextNode(message));
    const container = document.querySelector(".container");
    const main = document.querySelector(".main");
    container.insertBefore(div, main);

    setTimeout(() => document.querySelector(".alert").remove(), 3000);
}

// Clear all feilds
function clearFields() {
    document.querySelector("#name").value = "";
    document.querySelector("#address").value = "";
    document.querySelector("#phone").value = "";
    document.querySelector("#email").value = "";
    document.querySelector("#website").value = "";
}


// Add Data
    document.querySelector("#student-form").addEventListener("submit", (e) =>{
        e.preventDefault();

        // Get form Values
        const name=document.querySelector("#name").value;
        const address=document.querySelector("#address").value;
        const phone=document.querySelector("#phone").value;
        const email=document.querySelector("#email").value;
        const website=document.querySelector("#website").value;

        // validate

        if (name == "" || address == "" || phone == "" || email == "" || website == "") {
            showAlert("please fill in all fields", "danger");
        } else {
            if(selectorRow == null){
                const list =document.querySelector("#student-list");
                const row =document.createElement("tr");

                row.innerHTML = `
                    <td>${name}</td>
                    <td>${address}</td>
                    <td>${phone}</td>
                    <td>${email}</td>
                    <td>${website}</td>
                    <td>
                    <a href="#" class="btn btn-warning btn-sm edit">EDIT</a>
                    <a href="#" class="btn btn-danger btn-sm delete">DELETE</a>
                `;
                list.appendChild(row);
                selectorRow = null;
                showAlert("student added", "success");
            }
            else {
                selectorRow.children[0].textContent = name;
                selectorRow.children[1].textContent = address;
                selectorRow.children[2].textContent = phone;
                selectorRow.children[3].textContent = email;
                selectorRow.children[4].textContent = website;
                selectorRow = null;
                showAlert("Student info edited", "info");
            }

            clearFields();
        }
    });

    // Edit Data
    document.querySelector("#student-list").addEventListener("click", (e) => {
        target = e.target;
        if(target.classList.contains("edit")){
            selectorRow = target.parentElement.parentElement;
            document.querySelector("#name").value = selectorRow.children[0].textContent;
            document.querySelector("#address").value = selectorRow.children[1].textContent;
            document.querySelector("#phone").value = selectorRow.children[2].textContent;
            document.querySelector("#email").value = selectorRow.children[3].textContent;
            document.querySelector("#website").value = selectorRow.children[4].textContent;
        }
    });

// delete data
document.querySelector("#student-list").addEventListener("click", (e) => {
    target = e.target;
    if(target.classList.contains("delete")){
        target.parentElement.parentElement.remove();
        showAlert("A Data deleted", "danger");
    }
});